void main(void) {
	nChild1status = TRUE
	nChild2status = TRUE

	_beginthread(childThread1, 0, NULL);
	_beginthread(childThread2, 0, NULL);

	while ((nChild1_status == TRUE || (nChild2_status == TRUE))) { ; }

	printf("Both are done")

}

void childThread1(void *dummy) {
	int i;
	for (i = 0; i < REPEATS; i++) {
		sleep((clock_t)INTERVAL*CLOCKS_PER_SEC);
		printf("Child 1 Waiting %d more seconds to finish", REPEATS-i);
	}
}

void childThread2(void *dummy) {
	int i;
	for (i = 0; i < REPEATS; i++) {
		sleep((clock_t)INTERVAL*CLOCKS_PER_SEC);
		printf("Child 2 Waiting %d more seconds to finish", REPEATS-i);
	}
}